import styles from "./editWindow.module.css";

import {getEditPublicationForm} from "../feautures/editForm/editForm";

export const editPublicationWindow = (publication) =>{
    const edit = document.createElement('div')
    const main = document.getElementById('main')
    edit.classList.add(styles.container)
    edit.append(getEditPublicationForm(publication))
    return edit;
}